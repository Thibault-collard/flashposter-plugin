<?php

/**
 * FlashPoster | Write your blogging articles with AI
 *
 * Plugin Name: FlashPoster
 * Plugin URI:  https://wordpress.org/plugins/flashposter/
 * Description: This plugin is an add-on for website flashposter. It offers the ability to create and publish blogging articles by Artifical Intelligence.
 * Version:     0.0.1
 * Author:      FlashPoster
 * Author URI:  https://flashposter.ai
 * License:     GPL-2.0+
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt

 *
 * @package   flashPoster
 * @copyright Copyright (c) 2023, FlashPoster
 * @license   http://opensource.org/licenses/gpl-2.0.php GNU Public License
 */



 function flash_register_assets() {
	wp_enqueue_script( 'jquery' );
	wp_register_script('bootstrap', plugin_dir_url( __FILE__ ) . 'assets/js/bootstrap.min.js', array('jquery'), false, true);
    wp_enqueue_script('bootstrap');

	wp_enqueue_style( 'font-awesome', plugin_dir_url( __FILE__ ) . 'assets/css/font-awesome/css/all.css');
	wp_enqueue_style('bootstrap',plugin_dir_url( __FILE__ ) . 'assets/css/bootstrap.min.css');
	
}


add_action('admin_menu' , 'flash_mrn_add_menu');

function flash_mrn_add_menu(){
	flash_register_assets();
	add_menu_page('Connect to Flash Poster'  , 'Flash Poster'  , 'administrator' , 'connect' , 'flash_show_page_login' , plugin_dir_url( __FILE__ ) . 'images/lightning-grey.png' , 6);
	add_submenu_page('connection','Connection status', 'user Management','edit_themes','connection','flash_show_page_second');
	add_action('admin_post_connection_form','flash_show_page_second');
	
}

function flash_show_page_login(){
    ?>

<script>
jQuery(document).ready(function() { 
	jQuery(document).on("click","#btn-submit", function(){
			$("#btn-submit").val('Loading...').prop('readonly', 'readonly');
	});
})
	
</script>

<!------ Include the above in your HEAD tag ---------->
<style>
:read-only {
	border: none;
}
.register{
    background: rgb(56,82,163);
background: linear-gradient(-60deg, rgba(56,82,163,1) 69%, rgba(32,129,196,1) 86%);
    margin-top: 3%;
    padding-top: 3%;
	padding-bottom:3%;
}
.register-left{
    text-align: center;
    color: #fff;
    margin-top: 4%;
}
.register-left input{
    border: none;
    border-radius: 1.5rem;
    padding: 2%;
    width: 60%;
    background: #f8f9fa;
    font-weight: bold;
    color: #383d41;
    margin-top: 30%;
    margin-bottom: 3%;
    cursor: pointer;
}
.register-right{
    background: #FAFEFF;
    opacity: 100%;
    border-top-left-radius: 13% 50%;
    border-bottom-left-radius: 13% 50%;
}
.register-left img{
    margin-top: 15%;
    margin-bottom: 5%;
    width: 75%;
    -webkit-animation: mover 2s infinite  alternate;
    animation: mover 1s infinite  alternate;
}
@-webkit-keyframes mover {
    0% { transform: translateY(0); }
    100% { transform: translateY(-30px); }
}
@keyframes mover {
    0% { transform: translateY(0); }
    100% { transform: translateY(-30px); }
}
.input-box{
    background: #EDF5FA;
    border-radius: 0.8rem;
    border: none;
    height: 50px;
    width: 300px;
    padding: 20px;
}
.input-keyword{
    background: 'white';
    border-radius: 0.8rem;
    border: 1px solid #8c8f94;
    padding: 20px;
	margin-left: 14px;
	width:647px;
	height:100px
}

}
.register-left p{
    font-weight: lighter;
    padding: 12%;
    margin-top: -9%;
}
.register .register-form{
    padding: 10%;
    margin-top: 10%;
}
.btnRegister{
    float: right;
    margin-top: 2%;
    margin-left:361px;
    border: none;
    border-radius: 0.6rem;
    background: #3852a3;
    padding: 2%;
    color: #fff;
    font-weight: 600;
    width: 44%;
    cursor: pointer;
}
.btnReset{
    float: right;
    margin-top: 23%;
    margin-left:361px;
    border: none;
    border-radius: 0.6rem;
    background: #3852a3;
    padding: 1%;
    color: #fff;
    font-weight: 600;
    width: 21%;
    cursor: pointer;
}	
.register .nav-tabs{
    margin-top: 3%;
    border: none;
    background: #1C80C4;
    border-radius: 1.5rem;
    width: 28%;
    float: right;
}
.register .nav-tabs .nav-link{
    padding: 2%;
    height: 34px;
    font-weight: 600;
    color: #fff;
    border-top-right-radius: 1.5rem;
    border-bottom-right-radius: 1.5rem;
}
.register .nav-tabs .nav-link:hover{
    border: none;
}
.register .nav-tabs .nav-link.active{
    width: 100px;
    color: #1C80C4;
    border: 2px solid #1C80C4;
    border-top-left-radius: 1.5rem;
    border-bottom-left-radius: 1.5rem;
}
.register-heading{
    text-align: center;
    margin-top: 8%;
    margin-bottom: -15%;
    color: #3852a3;
}
</style>
<div class="container register">
                <div class="row">
                    <div class="col-md-3 register-left">
						<img src="<?php echo plugin_dir_url( __FILE__ ) . 'images/logo_single_no_border.png'; ?>">
                    </div>
                    <div class="col-md-9 register-right">
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">	
									<?php
										if (isset($_POST['reset'])) {
											update_option('token_sl', '');
										  }
	
										if(get_option('token_sl')){
											?>
											<h3 class="register-heading" style='margin-top:100px'> <i class="fa fa-check-circle" style='color:green' aria-hidden="true"></i> Your website is connected to Flash Poster </h3>
											<form action="" method="POST">
											  <input type="submit" class="btnReset" name="reset" value='Reset connection'>
											</form>
											<!-- ... -->
										<?php
										} else {
											?>
											<h3 class="register-heading"> Connect with your Flash Poster credentials</h3>
											<form action="<?php echo esc_url(admin_url('admin.php?page=connection')); ?>" method="POST" name="connection_form">
												<div class="row register-form">
													<div class="col-md-6">
														<div class="form-group">
															<input type="email" class="input-box" placeholder="Email" name="email" value="" />
														</div>
													</div>
													<div class="col-md-6">
														<div class="form-group">
															<input type="password" class="input-box " placeholder="Password" name="password" value="" />
														</div>
													</div>
															<textarea type="keywords" class="input-keyword " placeholder="Type keywords about your website content separated by a ';'. If you leave it empty, the keywords will be generated from your current blog posts. You can add or modify the keywords later." name="keywords" value=""></textarea>
														<input type="submit"  id='btn-submit' class="btnRegister" value='Connect'/>
														
													</div>
											</form>
										<?php
										}
									?>
                            </div>
                           
                        </div>
                    </div>
                </div>

            </div>
	<?php
}

function flash_show_page_second()
{
	
    ?>
		
<!------ Include the above in your HEAD tag ---------->
<style>
.register{
    background: rgb(56,82,163);
background: linear-gradient(-60deg, rgba(56,82,163,1) 69%, rgba(32,129,196,1) 86%);
    margin-top: 3%;
    padding-top: 3%;
	padding-bottom:3%;
}
.btnReset{
    float: right;
    margin-top: 23%;
    margin-left:361px;
    border: none;
    border-radius: 0.6rem;
    background: #3852a3;
    padding: 1%;
    color: #fff;
    font-weight: 600;
    width: 21%;
    cursor: pointer;
}	
.register-left{
    text-align: center;
    color: #fff;
    margin-top: 4%;
}
.register-left input{
    border: none;
    border-radius: 1.5rem;
    padding: 2%;
    width: 60%;
    background: #f8f9fa;
    font-weight: bold;
    color: #383d41;
    margin-top: 30%;
    margin-bottom: 3%;
    cursor: pointer;
}
.register-right{
    background: #FAFEFF;
    opacity: 100%;
    border-top-left-radius: 13% 50%;
    border-bottom-left-radius: 13% 50%;
}
.register-left img{
    margin-top: 15%;
    margin-bottom: 5%;
    width: 75%;
    -webkit-animation: mover 2s infinite  alternate;
    animation: mover 1s infinite  alternate;
}
@-webkit-keyframes mover {
    0% { transform: translateY(0); }
    100% { transform: translateY(-30px); }
}
@keyframes mover {
    0% { transform: translateY(0); }
    100% { transform: translateY(-30px); }
}
.input-box{
    background: #EDF5FA;
    border-radius: 0.8rem;
    border: none;
    height: 50px;
    width: 300px;
    padding: 20px;
}
input:focus {
  outline: 1px solid #62AAD3;
}
}
.register-left p{
    font-weight: lighter;
    padding: 12%;
    margin-top: -9%;
}
.register .register-form{
    padding: 10%;
    margin-top: 10%;
}
.btnRegister{
    float: right;
    margin-top: 10%;
    margin-right: 13px;
    border: none;
    border-radius: 0.6rem;
    background: #3852a3;
    padding: 2%;
    color: #fff;
    font-weight: 600;
    width: 50%;
    cursor: pointer;
}
.register .nav-tabs{
    margin-top: 3%;
    border: none;
    background: #1C80C4;
    border-radius: 1.5rem;
    width: 28%;
    float: right;
}
.register .nav-tabs .nav-link{
    padding: 2%;
    height: 34px;
    font-weight: 600;
    color: #fff;
    border-top-right-radius: 1.5rem;
    border-bottom-right-radius: 1.5rem;
}
.register .nav-tabs .nav-link:hover{
    border: none;
}
.register .nav-tabs .nav-link.active{
    width: 100px;
    color: #1C80C4;
    border: 2px solid #1C80C4;
    border-top-left-radius: 1.5rem;
    border-bottom-left-radius: 1.5rem;
}
.register-heading{
    text-align: center;
    margin-top: 8%;
    margin-bottom: -15%;
    color: #3852a3;
}
</style>
<div class="container register">
                <div class="row">
                    <div class="col-md-3 register-left">
						<img src="<?php echo plugin_dir_url( __FILE__ ) . 'images/logo_single_no_border.png'; ?>">
                    </div>
                    <div class="col-md-9 register-right">
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
								
								<?php 
									if (isset($_POST['reset'])) {
										update_option('token_sl', '');
									}
									if ((isset($_POST['email']) && isset($_POST['password'])) || get_option('token_sl')) {
										$email = sanitize_email($_POST['email']);
										$password = sanitize_text_field($_POST['password']);
										$keywords = sanitize_text_field($_POST['keywords']);
										$resp = flash_validate_login_details($email,$password,$keywords);										

										if($resp != true)
										{
											?>
												<h3 class="register-heading" style="margin-top:100px"> <i class="fa fa-times-circle" style='color:red' aria-hidden="true"></i> Error: Invalid credentials </h3>
												<div style="margin-top:190px; text-align: center;"> <a style='color: #3852a3;font-weight:600' href='<?php echo esc_url(admin_url('admin.php?page=connect'));?>'> < Back to login </a></div>
												
											<?php
											return;
										}
										
										?>
										 <h3 class="register-heading" style='margin-top:100px'> <i class="fa fa-check-circle" style='color:green' aria-hidden="true"></i> Your website is connected to Flash Poster </h3>
										<form action="" method="POST">
											  <input type="submit" class="btnReset" name="reset" value='Reset connection'>
											</form>
										<?php
									}
									else {
										?>
											<h3 class="register-heading" style="margin-top:100px"> <i class="fa fa-times-circle" style='color:red' aria-hidden="true"></i> Please enter valid credentials </h3>
											<div style="margin-top:190px; text-align: center;"> <a style='color: #3852a3;font-weight:600' href='<?php echo esc_url(admin_url('admin.php?page=connect'));?>'> < Back to login </a></div>
										<?php
									}
	
									?>
									<?php
								?>
                                </div>
                            </div>
                           
                        </div>
                    </div>
                </div>
	<?php
}

function flash_validate_login_details($email,$password,$keywords){
	$offset  = (float) get_option( 'gmt_offset' );
	$hours   = (int) $offset;
	$minutes = ( $offset - $hours );

	$sign      = ( $offset < 0 ) ? '-' : '';
	$abs_hour  = abs( $hours );
	$abs_mins  = abs( $minutes * 60 );
	$tz_offset = sprintf( '%s%02d.%02d', $sign, $abs_hour, $abs_mins );
	
	$posts = get_posts( array(
		'post_type' =>  'post',
		'post_status' => 'publish',
		'numberposts' => -1,
	));
	
	$country_data = flash_get_country_data();
	
	$valid =  false;

	$response = wp_remote_post( 'https://api.flashposter.ai/v1/user/tokenWp',
	array( 'headers' => array( 'Content-Type' => 'application/json; charset=utf-8' ), 
		  'method' => 'POST',
		  'data_format' => 'body',
        'timeout'     => 45,
        'redirection' => 5,
        'httpversion' => '1.0',
        'blocking'    => true,
        'headers'     => array( 'Content-Type' => 'application/json' ),
        'body' => wp_json_encode( 
		array(
			'email' => $email,
			'password' => $password,
			'keywords' => $keywords,
			'url' => get_site_url(), 
			'description' => get_bloginfo( 'description' ), 
			'icon' => get_site_icon_url(), 
			'timezone' => $tz_offset, 
			'posts' => $posts, 
			'countryCode' => $country_data[0], 
			'countryCurrency' => $country_data[1] 
			) 
		) 
	) 
	); 
	
	$response_body = wp_remote_retrieve_body($response); 
	$result = json_decode($response_body,true); 
	
	if ( $result['status'] === 'success' ) { 
		if ( get_option( 'token_sl' ) || get_option( 'token_sl' ) === '' ) { 
			update_option( 'token_sl', $result['token'] ); 
		} else { 
			add_option( 'token_sl', $result['token'] ); 
		} 
		$valid = true; 
	} else { 
		$valid = false; 
	} 
	return $valid;
}

function flash_get_country_data(){ 
	$ip = $_SERVER['REMOTE_ADDR']; 

	if (!$ip) { 
		return false;
	}

	$endpoint = "http://www.geoplugin.net/json.gp?ip=" . $ip; 
	$response = wp_remote_get($endpoint); 
	if (is_wp_error($response)) { 
		return false; 
	} 
	$body = wp_remote_retrieve_body($response); 
	$result = json_decode($body, true); 
	$countrycode = $result['geoplugin_countryCode']; 
	$countrycurrency = $result['geoplugin_currencyCode']; 
	return [$countrycode, $countrycurrency]; 
}

function flash_create_meta($request){
	$body = $request->get_json_params();
	$token = get_option('token_sl');
	if($body['token_sl'] === $token){
		update_post_meta( $post_id = $body['id'],$key ='_yoast_wpseo_metadesc', $value = $body['value-metadesc'] );
		update_post_meta( $post_id = $body['id'] , $key = '_yoast_wpseo_title', $value = $body['value-title'] );
		return new WP_REST_Response(get_post_meta($body['id']));
	}
	else{
		return 'invalid token provided';
	}
}

function flash_get_users($request){
	$param = $request->get_json_params();
	$token = get_option('token_sl');
	if($param['token_sl'] === $token){
		$users = get_users();
		return $users;
	}else{
		return 'invalid token provided';
	}
}

function flash_add_user($request){
	$body = $request->get_json_params();
	$token = get_option('token_sl');
	if($param['token_sl'] === $token){
		$user_id = wp_create_user( $body['username'],$body['password'],$body['email']);
  		return $user_id; 
	}else{
		return 'invalid token provided';
	}
}

function flash_get_posts($request){
	$body = $request->get_json_params();
	$token = get_option('token_sl');
	if($body['token_sl'] === $token){
		$posts = get_posts( array(
		  'post_type' => 'post',
		  'post_status' => 'publish',
		  'numberposts' => -1,
		));
		return $posts;
	}
	else{
		return 'invalid token provided';
	}
}
function flash_add_post($request){
	$body = $request->get_json_params();
	$token = get_option('token_sl');
	
	if($body['token_sl'] === $token){
		$new_post = array(
			'post_title' => $body['title'],
			'post_type' => 'post',
			'post_status' => $body['status'],
			'post_author' => $body['author'],
			'post_date' => $body['date'],
			'post_name' => $body['slug'],
			'post_content' => $body['content'],
			'post_category' => $body['categories'],
			'tags_input' => $body['tags'],
			'_thumbnail_id' => $body['featured_media']
		);

		$post_id = wp_insert_post( $new_post );	
		$post_data = get_post($post_id);
		return $post_data;
	}
	else{
		return 'invalid token provided';
	}
}

function flash_get_medias($request){
	$body = $request->get_params();
	$token = get_option('token_sl');
	if($body['token_sl'] === $token){
		$args = array(
			'post_type' => 'attachment',
			'post_mime_type' => 'image/jpeg,image/jpg,image/png',
			'post_status' => 'inherit',
			'posts_per_page' => -1,
			'orderby' => 'id',
			'order' => 'ASC'
		);
		$query_images = new WP_Query( $args );
		return $query_images->posts;
	}else{
		return 'invalid token provided';
	}
}

function flash_add_media($request)
{	
	$body = $request->get_params();
	$token = get_option('token_sl');
	if($body['token_sl'] === $token){
		if(!function_exists('media_handle_upload')) {
			require_once(ABSPATH . "wp-admin" . '/includes/image.php');
			require_once(ABSPATH . "wp-admin" . '/includes/file.php');
			require_once(ABSPATH . "wp-admin" . '/includes/media.php');
		}

		$img_id = media_handle_sideload( $_FILES['image'], array('test_form' => FALSE));
		if (!empty($img_id)) { 
			return 'invalid img provided';
		}

		if ( isset($img['error']) ) {
			$result['message'] = $img['error'];
			return $result;
		}	
		$args = array(
			'attachment_id' => $img_id,
			'post_type' => 'attachment',
			'post_mime_type' => 'image/jpeg,image/jpg,image/png',
			'post_status' => 'inherit',
			'posts_per_page' => -1,
			'orderby' => 'id',
			'order' => 'ASC'
		);
		$query_images = new WP_Query( $args );
		return $query_images;
	}else{
		return 'invalid token provided';
	}
}

function flash_add_media_from_url($request)
{	
	$body = $request->get_params();
	$token = get_option('token_sl');
	if($body['token_sl'] === $token){
		if(!function_exists('media_handle_upload')) {
			require_once(ABSPATH . "wp-admin" . '/includes/image.php');
			require_once(ABSPATH . "wp-admin" . '/includes/file.php');
			require_once(ABSPATH . "wp-admin" . '/includes/media.php');
		}
		
		$url = $body['url'];

		$tmp = download_url( $url );

		$file_array = array(
			'name' => $body['name_img'].'.webp',
			'tmp_name' => $tmp
		);

		if ( is_wp_error( $tmp ) ) {
			@unlink( $file_array[ 'tmp_name' ] );
			return $tmp;
		}

		$post_id = '0';
		
		$img_id = media_handle_sideload( $file_array, $post_id );

		
		//if there is an error show it
		if ( isset($img['error']) ) {
			$result['message'] = $img['error'];
			return $result;
		}	
		$args = array(
			'attachment_id' => $img_id,
			'post_type' => 'attachment',
			'post_mime_type' => 'image/jpeg,image/jpg,image/png,image/webp',
			'post_status' => 'inherit',
			'posts_per_page' => -1,
			'orderby' => 'id',
			'order' => 'ASC'
		);
		$query_images = new WP_Query( $args );
		return $query_images;
	}else{
		return 'invalid token provided';
	}
}

function flash_get_categories($request){
	$param = $request->get_json_params();
	$token = get_option('token_sl');
	if($param['token_sl'] === $token){
		$categories = get_terms( 'category', array(
		'orderby'    => 'count',
		'hide_empty' => 0,
		));
		return $categories;
	}else{
		return new WP_Error( 'token_error', __( 'invalid token provided' ) );
	}
}

function flash_get_tags($request){
	$param = $request->get_json_params();
	$token = get_option('token_sl');
	if($param['token_sl'] === $token){
		$tags = get_terms( 'post_tag', array(
		'orderby'    => 'count',
		'hide_empty' => 0,
		));
		return $tags;
	}else{
		return new WP_Error( 'token_error', __( 'invalid token provided' ) );
	}
}

function flash_add_tag($request){
	$body = $request->get_json_params();
	$token = get_option('token_sl');
	if($body['token_sl'] === $token){
		return wp_insert_term( $body["name"], 'post_tag' );
	}else{
		return 'invalid token provided';
	}
}

function flash_add_category($request){
	$catarr = $request->get_json_params();
	$token = get_option('token_sl');
	if($param['token_sl'] === $token){
		$cat_defaults = array(
			'cat_ID'               => 0,
			'taxonomy'             => 'category',
			'cat_name'             => '',
			'category_description' => '',
			'category_nicename'    => '',
			'category_parent'      => '',
		);
		$catarr = wp_parse_args( $catarr, $cat_defaults );

		if ( '' === trim( $catarr['cat_name'] ) ) {
			if ( ! $wp_error ) {
				return 0;
			} else {
				return new WP_Error( 'cat_name', __( 'You did not enter a category name.' ) );
			}
		}

		$catarr['cat_ID'] = (int) $catarr['cat_ID'];

		// Are we updating or creating?
		$update = ! empty( $catarr['cat_ID'] );

		$name        = $catarr['cat_name'];
		$description = $catarr['category_description'];
		$slug        = $catarr['category_nicename'];
		$parent      = (int) $catarr['category_parent'];
		if ( $parent < 0 ) {
			$parent = 0;
		}

		if ( empty( $parent )
			|| ! term_exists( $parent, $catarr['taxonomy'] )
			|| ( $catarr['cat_ID'] && term_is_ancestor_of( $catarr['cat_ID'], $parent, $catarr['taxonomy'] ) ) ) {
			$parent = 0;
		}

		$args = compact( 'name', 'slug', 'parent', 'description' );

		if ( $update ) {
			$catarr['cat_ID'] = wp_update_term( $catarr['cat_ID'], $catarr['taxonomy'], $args );
		} else {
			$catarr['cat_ID'] = wp_insert_term( $catarr['cat_name'], $catarr['taxonomy'], $args );
		}

		if ( is_wp_error( $catarr['cat_ID'] ) ) {
			if ( $wp_error ) {
				return $catarr['cat_ID'];
			} else {
				return 0;
			}
		}
		return $catarr['cat_ID']['term_id'];
	}else{
		return 'invalid token provided';
	}
}


function flash_at_rest_init()
{
   	$namespace = 'wp/v2';
	register_rest_route($namespace, '/fl_add_metadata/', array('methods'   => 'POST','callback'  => 'flash_create_meta'));
	register_rest_route($namespace, '/fl_get_users/', array('methods'   => 'POST','callback'  => 'flash_get_users'));
	register_rest_route($namespace, '/fl_user/', array('methods'   => 'POST','callback'  => 'flash_add_user'));
	register_rest_route($namespace, '/fl_get_categories/', array('methods'   => 'POST','callback'  => 'flash_get_categories'));
	register_rest_route($namespace, '/fl_category/', array('methods'   => 'POST','callback'  => 'flash_add_category'));
	register_rest_route($namespace, '/fl_get_tags/', array('methods'   => 'POST','callback'  => 'flash_get_tags'));
	register_rest_route($namespace, '/fl_add_tag/', array('methods'   => 'POST','callback'  => 'flash_add_tag'));
	register_rest_route($namespace, '/fl_get_posts/', array('methods'   => 'POST','callback'  => 'flash_get_posts'));
	register_rest_route($namespace, '/fl_post/', array('methods'   => 'POST','callback'  => 'flash_add_post'));
	register_rest_route($namespace, '/fl_get_media/', array('methods'   => 'POST','callback'  => 'flash_get_medias'));
	register_rest_route($namespace, '/fl_add_media/', array('methods'   => 'POST','callback'  => 'flash_add_media'));
	register_rest_route($namespace, '/fl_add_media_from_url/', array('methods'   => 'POST','callback'  => 'flash_add_media_from_url'));
}

add_action('rest_api_init', 'flash_at_rest_init');

