=== FlashPoster Plugin ===
Contributors: Thibault Collard-bovy, FlashPoster
Tags: blogging, artificial intelligence, seo, article creation, 

Requires at least: 5.2
Tested up to: 6.3
Stable tag: 0.0.1

License: GPLv2 or later

The easiest to use wordpress website integrated with FlashPoster. No coding required.

== Description ==
The plugin library currently contains routes to share data with FlashPoster.ai. This plugin allows you to easily post or access data for your WordPress website.

= Bugs =
If you find an issue with FlashPoster Plugin, let us know by sending an email to support@flashposter.ai!

= Contributions =
Anyone is welcome to contribute to FlashPoster Plugin.

== Installation ==
Upload FlashPoster Plugin, activate it, and you're done!

Navigate to wp-admin -> Appearance -> Customize and you will see a new tab named 'FlashPoster Plugin'


